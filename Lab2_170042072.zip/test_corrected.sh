#!/bin/sh

# Author : Rafid Haque
# Institution : IUT

for var in "$@"
do
  echo $var
done
